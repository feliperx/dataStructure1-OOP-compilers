/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.ClassRoom;
/**
 *
 * @author olive
 */
public class Salas {
    public static ArrayList<ClassRoom> todasAsSalas() {
        
        BD bancoDados = new BD();        
        //ArrayDinâmico para retorna todas as salas do banco de dados
        ArrayList<ClassRoom> salasCadastradas = new ArrayList<ClassRoom>();
        
        if ( ! bancoDados.getConnectiom() ) {
            return null;
        }
        String sql = "SELECT id,name, digital_board, description FROM classroom";
        try {
            PreparedStatement statement = bancoDados.connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                    
                //PegaOsDadosDoBancoDeDadosEInsereNaClassRoom
                ClassRoom salaAuxiliar = new ClassRoom();
                salaAuxiliar.setId( resultSet.getInt( "id" ) );
                salaAuxiliar.setName( resultSet.getString( "name" ) );
                salaAuxiliar.setDigitalBoard(resultSet.getBoolean( "digital_board" ) );
                salaAuxiliar.setDescription( resultSet.getString( "description" ) );
                    
                salasCadastradas.add( salaAuxiliar );
            }

            resultSet.close();
            statement.close();
            bancoDados.close();
                
            return salasCadastradas;
                
        } catch (SQLException e) {
            JOptionPane.showMessageDialog( null, "Problema na conexão com o banco de dados! " + e.toString() );      
            return null;
        }
    }
    
    public static ArrayList<ClassRoom> pesquisaSala( String nome ) {
        
        BD bancoDados = new BD();
        ArrayList<ClassRoom> salasEncontradas = new ArrayList<ClassRoom>();
        
        if ( ! bancoDados.getConnectiom() ) {
            return null;
        }
        
        String sql = "SELECT id,name, digital_board, description FROM classroom WHERE name LIKE ?";
            
        try {
            PreparedStatement statement = bancoDados.connection.prepareStatement( sql );
            
            statement.setString( 1, "%" + nome + "%" );
            
            ResultSet resultSet = statement.executeQuery();
            
            while( resultSet.next() ) {
                //PegaOsDadosDoBancoDeDadosEInsereNaClassRoom
                ClassRoom salaAuxiliar = new ClassRoom();
                salaAuxiliar.setId( resultSet.getInt( "id" ) );
                salaAuxiliar.setName( resultSet.getString( "name" ) );
                salaAuxiliar.setDigitalBoard(resultSet.getBoolean( "digital_board" ) );
                salaAuxiliar.setDescription( resultSet.getString( "description" ) );
                    
                salasEncontradas.add( salaAuxiliar );
            }
            return salasEncontradas;
        } catch (SQLException ex) {
            Logger.getLogger(Salas.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public static ArrayList<ClassRoom> pesquisaSala( String nome , boolean lousaDigital) {
        
        BD bancoDados = new BD();
        ArrayList<ClassRoom> salasEncontradas = new ArrayList<ClassRoom>();
        
        if ( ! bancoDados.getConnectiom() ) {
            return null;
        }
        
        String sql = "SELECT id,name, digital_board, description FROM classroom WHERE name LIKE ? AND digital_board = ?";
            
        try {
            PreparedStatement statement = bancoDados.connection.prepareStatement( sql );
            
            statement.setString( 1, "%" + nome + "%" );
            statement.setBoolean( 2, lousaDigital );
            
            ResultSet resultSet = statement.executeQuery();
            
            while( resultSet.next() ) {
                //PegaOsDadosDoBancoDeDadosEInsereNaClassRoom
                ClassRoom salaAuxiliar = new ClassRoom();
                salaAuxiliar.setId( resultSet.getInt( "id" ) );
                salaAuxiliar.setName( resultSet.getString( "name" ) );
                salaAuxiliar.setDigitalBoard(resultSet.getBoolean( "digital_board" ) );
                salaAuxiliar.setDescription( resultSet.getString( "description" ) );
                    
                salasEncontradas.add( salaAuxiliar );
            }
            return salasEncontradas;
        } catch (SQLException ex) {
            Logger.getLogger(Salas.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public static ArrayList<ClassRoom> pesquisaSala( boolean lousaDigital) {
        
        BD bancoDados = new BD();
        ArrayList<ClassRoom> salasEncontradas = new ArrayList<ClassRoom>();
        
        if ( ! bancoDados.getConnectiom() ) {
            return null;
        }
        
        String sql = "SELECT id,name, digital_board, description FROM classroom WHERE digital_board = ?";
            
        try {
            PreparedStatement statement = bancoDados.connection.prepareStatement( sql );
            
            statement.setBoolean( 1, lousaDigital );
            
            ResultSet resultSet = statement.executeQuery();
            
            while( resultSet.next() ) {
                //PegaOsDadosDoBancoDeDadosEInsereNaClassRoom
                ClassRoom salaAuxiliar = new ClassRoom();
                salaAuxiliar.setId( resultSet.getInt( "id" ) );
                salaAuxiliar.setName( resultSet.getString( "name" ) );
                salaAuxiliar.setDigitalBoard(resultSet.getBoolean( "digital_board" ) );
                salaAuxiliar.setDescription( resultSet.getString( "description" ) );
                    
                salasEncontradas.add( salaAuxiliar );
            }
            return salasEncontradas;
        } catch (SQLException ex) {
            Logger.getLogger(Salas.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
