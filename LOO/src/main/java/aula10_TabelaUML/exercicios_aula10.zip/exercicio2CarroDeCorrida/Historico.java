/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula10_TabelaUML.exercicio2CarroDeCorrida;

/**
 *
 * @author felipex
 */
public class Historico {

    private int pontos;
    private int numeroVitorias;
    private int numeroPoles;
    private int classificacao;

    public Historico() {

    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getNumeroVitorias() {
        return numeroVitorias;
    }

    public void setNumeroVitorias(int numeroVitorias) {
        this.numeroVitorias = numeroVitorias;
    }

    public int getNumeroPoles() {
        return numeroPoles;
    }

    public void setNumeroPoles(int numeroPoles) {
        this.numeroPoles = numeroPoles;
    }

    public int getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(int classificacao) {
        this.classificacao = classificacao;
    }

}
