/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula09.pacotes;

/**
 *
 * @author felipex
 */
public class C3_teste {
    
    public static void main(String[] args) { 
        
        C1 x = new C1(); 
        C2 y = new C2(); 
        
        System.out.println(x.subtrair(4, 2));
        System.out.println(y.somar(3, 1));
        
        System.exit(0);
    }
    
}
