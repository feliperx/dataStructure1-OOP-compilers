/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula06_metodos;

/**
 *
 * @author felipex
 */
public class Exercicio02_Conta_teste { 
    
    	public static void main(String[] args) throws InterruptedException {
		
		Exercicio02_Conta.contar(3,15, 500);
	}
    
}
