/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula09.Exercicios;

/**
 *
 * @author felipex
 */
public class Exercicio08_Robo_main { 
    
    public static void main(String[] args) {
        
        Exercicio08_Robo r2 = new Exercicio08_Robo();
        
        r2.andar(); 
        
        r2.falar(); 
        
        r2.virar();
        
    System.exit(0);
    }
    
}
