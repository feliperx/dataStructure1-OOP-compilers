package heap.v2;

public class Ordenacao {

    public int[] heapSort(int[] array) {
        long tempoinicial = System.currentTimeMillis();
        array = HeapSort.sort(array);
        long tempofinal = System.currentTimeMillis();
        long tempototal = tempofinal - tempoinicial;
        System.out.println("Tempo de Processamento de HeapSort: " + tempototal + "ms");
        return array;
    }

    public void imprimirVetor(int[] array) {
        for (int counter = 0; counter < (array.length - 1); counter++) {
            System.out.println(array[counter]);
        }
    }
}
