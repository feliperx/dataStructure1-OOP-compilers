package heap.v2;

import java.io.IOException;
import java.lang.NullPointerException;


public class Main {
        public static void main(String[] args) throws IOException {

            Arquivo arquivo = new Arquivo();
            Ordenacao ordenar = new Ordenacao();
            int[] arrayDesordenado = new int[10000];
            int[] arrayOrdenado = new int[10000];

            arrayDesordenado = arquivo.lerArquivo("arquivo.txt");
            arrayOrdenado = ordenar.heapSort(arrayDesordenado);
            arquivo.gravarArquivo("ordenado.txt", arrayOrdenado); 
            
            System.exit(0);
        }
    }
