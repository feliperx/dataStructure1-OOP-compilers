/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashTableLista;

/**
 *
 * @author felipex
 */
public class HashTable {

    private Lista[] tab;
    private int TAM_MAX;

    public HashTable(int tam) {
        tab = new Lista[tam];
        TAM_MAX = tam;
        for (int i = 0; i < tam; i++) // inicializando
        {
            tab[i] = null;
        }
    }

    private int funcaohash(int chave) {
        int v = (int) chave;
        return (Math.abs(v) % TAM_MAX);
    }

    public void insere(int item) {
        int pos = funcaohash(item);
        if (tab[pos] != null) { // se esta ocupado
            if (tab[pos].busca_lista(item)) { // verificando se a chave ja existe
                System.out.println(" *** ATENCAO O item " + item + " ja foi cadastrado ***");
                return;
            }
        } else // se estiver livre
        {
            tab[pos] = new Lista();
        }

        tab[pos].insere_lista(item);
    }

    public void apaga(int chave) {
        int pos = busca((int) chave);
        if (pos != -1) {
            tab[pos].apaga_lista(chave);
        } else {
            System.out.println("\n Item nao encontrado");
        }
    }

    public void imprime() {
        for (int i = 0; i < TAM_MAX; i++) {
            System.out.print("\n HASH[" + i + "] -> ");
            if (tab[i] != null) {
                tab[i].imprime_lista();
            }
            System.out.print("null");
        }
    }

    public int busca(int chave) {
        for (int i = 0; i < TAM_MAX; i++) {
            if (tab[i] != null) {
                if (tab[i].busca_lista(chave)) {
                    return i;
                }
            }
        }
        return -1;
    }

}
